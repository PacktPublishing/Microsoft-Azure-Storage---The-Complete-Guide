﻿#https://docs.microsoft.com/en-us/azure/storage/common/storage-account-create?tabs=azure-powershell

#Connect to Azure
Connect-AzAccount


Select-AzSubscription 



#Get Help
Get-Help New-AzStorageAccount -Online





Get-AzStorageAccount





#Create a new storage account. Make sure storage account name is unique
New-AzStorageAccount -ResourceGroupName 'azurecourse-eastus2-rg' `
  -Name azstorageaccountdemo01 `
  -Location northeurope `
  -SkuName Standard_RAGRS `
  -Kind StorageV2





# To get the list of locations
 Get-AzLocation | select Location







$storageAcc= Get-AzStorageAccount -ResourceGroupName "azurecourse-eastus2-rg" -Name "azstorageaccountdemo01"      

## Get the storage account context  
$context= $storageAcc.Context    


#Create Context using connection string
$context = New-AzStorageContext -ConnectionString "DefaultEndpointsProtocol=https;AccountName=azstorageaccountdemo01;AccountKey=sxbWpDwJ6vMfiquWzYwwYLV1iQAj5eHw67n/EAPUpNWQbarcDg61RRNjTywwYW8xoGxQbZQqgVuswwR8uiImOw==;EndpointSuffix=core.windows.net"


#Create Context using SASToken
$context = New-AzStorageContext -StorageAccountName "azstorageaccountdemo01" -SasToken $SasToken








    




#Create a blob container
New-AzStorageContainer -Name "test" -Context $context -Permission Blob


New-AzStorageContainer -Name "mycontainer" -Context $context -Permission  Container





# List your containers
Get-AzStorageContainer -Context $context






$storageAcc= Get-AzStorageAccount -ResourceGroupName "azurecourse-eastus2-rg" -Name "azstorageaccountdemo01"      

## Get the storage account context  
$context= $storageAcc.Context





# Upload a single file
Set-AzStorageBlobContent -Container "mycontainer" -File "C:\Users\techs\Desktop\Azure_Storage\demo\sample_image.png" -Context $context

    
# Upload all files and sub directories
Get-ChildItem -Path "C:\Users\techs\Desktop\Azure_Storage\demo\" -Recurse |
 Set-AzStorageBlobContent -Container "mycontainer"  -Context $context -Force





 

# List Blobs in a container
Get-AzStorageBlob  -Container "mycontainer" -Context $context
 
Get-AzStorageBlob  -Container "mycontainer" -Context $context -Blob '*.png'









# Download single file from azure container
Get-AzStorageBlobContent -Container "mycontainer" -Context $context -Blob 'sample_image.png' -Destination "C:\Users\techs\Desktop\Azure_Storage\download"





# Download multiple files
 $all_blobs = Get-AzStorageBlob  -Container "mycontainer" -Context $context

 $all_blobs | ForEach-Object {
    Get-AzStorageBlobContent -Container "mycontainer" -Context $context -Blob $_.Name -Destination "C:\Users\techs\Desktop\Azure_Storage\download" -Force
 }






# Delete Blobs

Get-AzStorageBlob  -Container "mycontainer" -Context $context


Get-AzStorageBlob  -Container "mycontainer" -Context $context | Remove-AzStorageBlob




# Delete Container(s)

Remove-AzStorageContainer -Name mycontainer -Context $context 
Remove-AzStorageContainer -Name test -Context $context -Force


# Delete storage account
Remove-AzStorageAccount -Name azstorageaccountdemo01 -ResourceGroupName azurecourse-eastus2-rg -Force